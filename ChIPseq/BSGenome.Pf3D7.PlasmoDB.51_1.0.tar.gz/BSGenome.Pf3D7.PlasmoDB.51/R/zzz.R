###
###

.pkgname <- "BSGenome.Pf3D7.PlasmoDB.51"

.seqnames <- c(paste("Pf3D7_", c("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14"), "_v3",sep=""),"Pf3D7_MIT_v3","Pf3D7_API_v3")

.circ_seqs <- c("Pf3D7_MIT_v3","Pf3D7_API_v3")

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Plasmodium falciparum strain 3D7",
        common_name="Plasmodium_falciparum",
        genome="51",
        provider="PlasmoDB",
        release_date="April 19",
        source_url="http://plasmodb.org/common/downloads/release-51.0/Pfalciparum3D7/fasta/data/",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "Pf3D7"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

